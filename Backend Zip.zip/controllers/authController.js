// controllers/auth_controller.js
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const User = require('../models/user_model');
const { sendVerificationEmail, sendWelcomeEmail } = require('../services/emailService');
const JWT_SECRET = process.env.JWT_SECRET;
const { validateCollegeEmail } = require('../utils/validators');
const multer = require('multer');
const path = require('path');

// Set up Multer storage configuration
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/ProfilePicture');
  },
  filename: (req, file, cb) => {
    cb(null, `${Date.now()}${path.extname(file.originalname)}`);
  }
});

// Initialize Multer with the storage configuration
const upload = multer({ storage });

const signup = async (req, res) => {
  const { username, email, password, registrationType, usn } = req.body;
  
  try {
    // Validate email format
    if (!email || typeof email !== 'string') {
      return res.status(400).json({
        error: 'Invalid email format',
        message: 'Please provide a valid email address'
      });
    }

    // Convert email to lowercase for consistency
    const normalizedEmail = email.toLowerCase();

    // Check if it's a valid college email
    if (!validateCollegeEmail(normalizedEmail)) {
      return res.status(400).json({
        error: 'Invalid email domain',
        message: 'Please use your college email address (@students.git.edu)'
      });
    }

    // Check if email already exists
    const existingUser = await User.findOne({ email: normalizedEmail });
    if (existingUser) {
      return res.status(400).json({
        error: 'Email already registered',
        message: 'This email address is already registered'
      });
    }

    // Validate password
    if (!password || password.length < 8) {
      return res.status(400).json({
        error: 'Invalid password',
        message: 'Password must be at least 8 characters long'
      });
    }

    // Validate username
    if (!username || username.length < 3) {
      return res.status(400).json({
        error: 'Invalid username',
        message: 'Username must be at least 3 characters long'
      });
    }

    // Generate verification token
    const verificationToken = crypto.randomBytes(32).toString('hex');
    const hashedPassword = await bcrypt.hash(password, 10);
    
    const user = new User({
      username,
      email: normalizedEmail,
      password: hashedPassword,
      registrationType,
      usn,
      verificationToken,
      profilePicture: req.file ? req.file.filename : null // Store the filename in the user model
    });
    
    await user.save();
    
    // Send verification email
    await sendVerificationEmail(normalizedEmail, verificationToken);
    
    res.status(201).json({ 
      message: 'Registration successful. Please check your college email to verify your account.',
      userId: user._id
    });
  } catch (error) {
    console.error('Signup error:', error);
    res.status(400).json({ 
      error: 'Registration failed',
      message: error.message || 'An error occurred during registration'
    });
  }
};

const verifyEmail = async (req, res) => {
  const { token } = req.params;
  try {
    const user = await User.findOne({ verificationToken: token });
    if (!user) {
      return res.status(400).json({ error: 'Invalid verification token' });
    }
    
    user.isVerified = true;
    user.verificationToken = undefined;
    await user.save();
    
    // Send welcome email
    await sendWelcomeEmail(user.email);
    
    res.status(200).json({ message: 'Email verified successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Verification failed' });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user || !(await bcrypt.compare(password, user.password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    if (!user.isVerified) {
      return res.status(403).json({ error: 'Please verify your email first' });
    }
    
    const token = jwt.sign({ 
      userId: user._id,
      registrationType: user.registrationType 
    }, JWT_SECRET);
    
    res.json({ token, user: {
      id: user._id,
      username: user.username,
      email: user.email,
      registrationType: user.registrationType,
      paymentStatus: user.paymentStatus
    }});
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
};

const updateProfilePicture = [
  upload.single('profilePicture'), // Multer middleware to handle the file upload
  async (req, res) => {
    try {
      const userId = req.params.userId;
      const user = await User.findById(userId);
      if (!user) {
        return res.status(404).json({ error: 'User not found' });
      }

      // Update the profilePicture field in the user model
      user.profilePicture = req.file ? req.file.filename : null;
      await user.save();

      res.json({ message: 'Profile picture updated successfully', user });
    } catch (error) {
      res.status(500).json({ error: 'Failed to update profile picture' });
    }
  }
];

const getUserById = async (req, res) => {
  try {
    const userId = req.params.userId;
    const user = await User.findById(userId);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }
    res.json(user);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user' });
  }
};

const searchUsers = async (req, res) => {
    try {
        const { query } = req.query; // Get the search query from URL parameters
        
        if (!query || query.trim().length < 2) {
            return res.status(400).json({
                error: 'Search query must be at least 2 characters long'
            });
        }

        // Create a search regex that's case insensitive
        const searchRegex = new RegExp(query, 'i');

        // Search users with completed payments who match any of the search criteria
        const users = await User.find({
            $and: [
                // Only include users with completed payments
                { paymentStatus: { $in: ['completed', 'received'] } },
                // Search across multiple fields
                {
                    $or: [
                        { username: searchRegex },
                        { email: searchRegex },
                        { usn: searchRegex }
                    ]
                }
            ]
        })
        .select('-password -verificationToken') // Exclude sensitive fields
        .limit(10) // Limit results to prevent overwhelming response
        .sort({ username: 1 }); // Sort results alphabetically

        // Format the response
        const formattedUsers = users.map(user => ({
            id: user._id,
            username: user.username,
            email: user.email,
            usn: user.usn,
            paymentStatus: user.paymentStatus,
            registrationType: user.registrationType,
            events: user.events.length,
            profilePicture: user.profilePicture || null
        }));

        // Return the results with metadata
        res.json({
            count: formattedUsers.length,
            query: query,
            users: formattedUsers
        });

    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({
            error: 'Failed to perform search',
            details: error.message
        });
    }
};

// Advanced search with pagination and filters
const advancedSearch = async (req, res) => {
    try {
        const {
            query,
            page = 1,
            limit = 10,
            registrationType,
            sortBy = 'username',
            sortOrder = 'asc'
        } = req.query;

        // Validate page and limit
        const pageNum = parseInt(page);
        const limitNum = parseInt(limit);
        
        if (pageNum < 1 || limitNum < 1) {
            return res.status(400).json({
                error: 'Invalid pagination parameters'
            });
        }

        // Build search criteria
        const searchCriteria = {
            paymentStatus: { $in: ['completed', 'received'] }
        };

        // Add search query if provided
        if (query && query.trim().length >= 2) {
            const searchRegex = new RegExp(query.trim(), 'i');
            searchCriteria.$or = [
                { username: searchRegex },
                { email: searchRegex },
                { usn: searchRegex }
            ];
        }

        // Add registration type filter if provided
        if (registrationType) {
            searchCriteria.registrationType = registrationType;
        }

        // Build sort object
        const sortObject = {};
        sortObject[sortBy] = sortOrder === 'desc' ? -1 : 1;

        // Execute search with pagination
        const totalUsers = await User.countDocuments(searchCriteria);
        const totalPages = Math.ceil(totalUsers / limitNum);

        const users = await User.find(searchCriteria)
            .select('-password -verificationToken')
            .sort(sortObject)
            .skip((pageNum - 1) * limitNum)
            .limit(limitNum);

        // Format the response
        const formattedUsers = users.map(user => ({
            id: user._id,
            username: user.username,
            email: user.email,
            usn: user.usn,
            paymentStatus: user.paymentStatus,
            registrationType: user.registrationType,
            events: user.events.length,
            profilePicture: user.profilePicture || null,
            teamIds: user.teamIds
        }));

        res.json({
            metadata: {
                total: totalUsers,
                page: pageNum,
                totalPages,
                limit: limitNum,
                query: query || null,
                registrationType: registrationType || null
            },
            users: formattedUsers
        });

    } catch (error) {
        console.error('Advanced search error:', error);
        res.status(500).json({
            error: 'Failed to perform advanced search',
            details: error.message
        });
    }
};

module.exports = { signup, login, verifyEmail, updateProfilePicture, getUserById ,advancedSearch,searchUsers};