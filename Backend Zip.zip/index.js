const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
app.use(express.json());
app.use(cors())
require('dotenv').config()
const connectToMongo = require('./config/db')
const port = process.env.PORT;
connectToMongo();

// Serve the uploads folder as a static directory
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

app.use('/api/auth', require('./routes/auth'));
app.use('/api/team', require('./routes/team'));
app.use('/api/paper', require('./routes/paperRoute'));
app.use('/api/admin',require('./routes/adminRoute'));
app.use('/api/event',require('./routes/eventRoute'))
app.get('/',(req,res)=>{
    return res.status(200).json({
    message:"Backend is running"
    })
}

)
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});