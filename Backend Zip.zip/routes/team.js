const express = require('express');
const router = express.Router();
const { 
registerForEvent,
completePayment,
registerTeam,
verifyPayment,
getEventStats,
getStats,
getUserWithEvents
} = require('../controllers/teamController');
const authMiddleware = require('../middleware/authMiddleware');

// Apply auth middleware to all registration routes
// router.use(authMiddleware);

router.post('/register/event/:id', registerForEvent);
router.post('/payment/complete', completePayment);
router.post('/register/team', registerTeam);
router.post('/payment/verify', verifyPayment);
router.get('/events/:eventId/stats', getEventStats);
router.get('/events/stats',getStats)
router.get('/get-user-event/:userId',getUserWithEvents)

module.exports = router;