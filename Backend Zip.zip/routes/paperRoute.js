const express = require('express');
const router = express.Router();
const {
    createPaper,
    getAllPapers,
    getPaperById,
    updatePaperStatus,
    filterPapers
} = require('../controllers/paperController');
const upload = require('../middleware/upload');

// Create a new paper presentation
router.post('/papers', upload.single('paperFile'), createPaper);

// Get all paper presentations (for admin)
router.get('/papers', getAllPapers);

// Get a specific paper presentation (for admin)
router.get('/papers/:id', getPaperById);

// Update a paper presentation (for admin)
router.patch('/papers/:id', updatePaperStatus);

// Filter paper presentations (for admin)
router.get('/papers/filter', filterPapers);

module.exports = router;