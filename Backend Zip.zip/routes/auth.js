const express = require('express');
const router = express.Router();
const { signup, login, verifyEmail, updateProfilePicture, getUserById ,searchUsers,advancedSearch} = require('../controllers/authController');

router.post('/signup', signup);
router.post('/login', login);
router.get('/verify-email/:token', verifyEmail);
router.put('/profile-picture/:userId', updateProfilePicture);
router.get('/user/:userId', getUserById);
router.get('/search', searchUsers);
router.get('/search/advanced', advancedSearch);

module.exports = router;