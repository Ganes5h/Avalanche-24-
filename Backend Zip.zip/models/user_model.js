const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    username: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    usn: { type: String, required: true },
    isVerified: { type: Boolean, default: false },
    paymentStatus: { type: String, enum: ['pending', 'completed','received'], default: 'pending' },
    registrationType: { type: String, enum: ['individual', 'team'], required: true },
    teamIds: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Team' }], 
    verificationToken: String,
    profilePicture: { type: String },
    paymentDetails: {
        amount: Number,
        transactionId: String,
        paymentDate: Date
    },
    events: [
        {
            event: { type: String }, 
            team: { type: mongoose.Schema.Types.ObjectId, ref: 'Team' } 
        }
    ]
}, { timestamps: true });

module.exports = mongoose.model('User', userSchema);
